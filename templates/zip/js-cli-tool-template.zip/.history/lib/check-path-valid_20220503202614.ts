import fs from 'fs';
import path from 'path';

function checkPathValidDirectory(pathname: string): boolean {
  return fs.statSync(pathname).isDirectory();
}

function checkPathValidFile(pathname: string): boolean {
  return fs.statSync(pathname).isFile();
}
