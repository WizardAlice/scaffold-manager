import { version } from '@/package.json';

function checkVersion() {

}
