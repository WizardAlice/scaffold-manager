import { version } from '@/package.json';
import fetch from 'isomorphic-fetch';

function checkVersion() {

}
