import chalk from 'chalk';
import fetch from 'isomorphic-fetch';

import { version } from '@/package.json';

export default function checkVersion() {

  console.log(chalk.bold.blue('Start to check version'))

}
