import chalk from 'chalk';

import { version } from '@/package.json';

export default function checkVersion() {

  console.log(chalk.bold.blue.bgWhite('Start to check version'));

}
