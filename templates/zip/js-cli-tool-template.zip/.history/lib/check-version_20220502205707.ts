import ora from 'ora';
import chalk from 'chalk';
import fetch from 'isomorphic-fetch';

import { version } from '@/package.json';

export default function checkVersion() {

  console.log(chalk.bold.blue.bgWhite('Start to check scaffold-manager version'));

  const spinner = ora({
    color: 'yellow',
    text: 'Fetching remote info'
  }).start();

  fetch('https://registry.npmjs.org/inquirer')
    .then(function (response) {
      if (response.status >= 400) {
        throw new Error("Bad response from server");
      }
      return response.json();
    })
    .catch(e => {
      spinner.fail();
      console.log(chalk.red('check upgrade error'));
      console.error(e);
    })

}
