import ora from 'ora';
import chalk from 'chalk';
import semver from 'semver';
import fetch from 'isomorphic-fetch';

import { name, version } from '../package.json';

export default function checkVersion() {

  console.log(chalk.bold.blue.bgWhite(`Start to check ${name} version`));

  const spinner = ora({
    color: 'yellow',
    text: 'Fetching remote info'
  }).start();

  fetch('https://registry.npmjs.org/inquirer')
    .then((response) => {
      if (response.status !== 200) {
        throw new Error("Bad response from server");
      }

      debugger
      const latestVersion = JSON.parse(response)['dist-tags'].latest;

      if (semver.lt(version, )) {
      }

    })
    .catch(e => {
      spinner.fail();
      console.log(chalk.red('check upgrade error'));
      console.error(e);
    })

}
