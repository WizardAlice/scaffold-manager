import ora from 'ora';
import chalk from 'chalk';
import semver from 'semver';
import fetch from 'node-fetch';

import { name, version } from '../package.json';

export default function checkVersion(): Promise<boolean> {
  const spinner = ora(chalk.bold.white.bgGreen(`Start to check ${name} version`)).start();

  return fetch('https://registry.npmjs.org/inquirer')
    .then((response) => {
      if (response.status !== 200) {
        throw new Error("Bad response from server");
      }

      // const latestVersion = JSON.parse(response)['dist-tags'].latest;
      console.log("🚀 ~ file: check-version.ts ~ line 18 ~ .then ~ response", response)

      if (semver.lt(version,)) {
      }

      return true;
    })
    .catch(e => {
      spinner.fail();
      console.log(chalk.red('check upgrade error'));
      console.error(e);
      return false;
    })

}
