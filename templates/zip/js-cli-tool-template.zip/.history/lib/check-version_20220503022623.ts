import ora from 'ora';
import chalk from 'chalk';
import semver from 'semver';
import axios from 'axios';

import { name, version } from '../package.json';

export default function checkVersion(): Promise<boolean> {
  const spinner = ora(chalk.bold.white.bgGreen(`Start to check ${name} version`)).start();

  axios({
    method: 'get',
    url: 'https://registry.npmjs.org/inquirer',
    responseType: 'json'
  })
    .then(function (response) {
      // const latestVersion = JSON.parse(response)['dist-tags'].latest;
      console.log("🚀 ~ file: check-version.ts ~ line 18 ~ .then ~ response", response)

      // if (semver.lt(version,)) {
      // }

      return true;
    })
    .catch(e => {
      spinner.fail();
      console.log(chalk.red('check upgrade error'));
      console.error(e);
      return false;
    });


}
