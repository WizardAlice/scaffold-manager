import ora from 'ora';
import chalk from 'chalk';
import semver from 'semver';
import axios from 'axios';

import { name, version } from '../package.json';

export default function checkVersion(): Promise<boolean> {
  const spinner = ora(chalk.bold.white.bgGreen(`Start to check ${name} version`)).start();

  return axios({
    method: 'get',
    url: 'https://registry.npmjs.org/inquirer',
    responseType: 'json'
  })
    .then((response) => {
      // const latestVersion = response['dist-tags'].latest;
      console.log("🚀 ~ file: check-version.ts ~ line 18 ~ .then ~ latestVersion", Object.keys(response))

      // if (semver.lt(version,)) {
      // }
      spinner.stop();

      return true;
    })
    .catch(e => {
      spinner.fail();
      console.log(chalk.red('check upgrade error'));
      console.error(e);
      return false;
    });


}
