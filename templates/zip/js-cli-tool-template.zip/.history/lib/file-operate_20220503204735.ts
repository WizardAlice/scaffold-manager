export function zipFolder(sourceFolder: string, destZip: string) {
  var zip = new AdmZip();
  zip.addLocalFolder(sourceFolder);
  zip.writeZip(destZip);
}
