import ora from 'ora';
import chalk from 'chalk';
import AdmZip from 'adm-zip';


export function unzip(filepath: string, destFolder: string){
  var zip = new admZip(zipFile);

  var zipEntries = zip.getEntries();
  for(var i=0; i<zipEntries.length; i++){
      var entry = zipEntries[i];
      entry.entryName = iconv.decode(entry.rawEntryName, 'gbk');
  }

  zip.extractAllTo(destFolder, true);
}

export function zipFolder(from: string, to: string) {
  var zip = new AdmZip();
  zip.addLocalFolder(from);
  zip.writeZip(to);
}

export function writeZipFile(from: string, to: string) {
  const spinner = ora(chalk.green(`Copying template from ${from} to ${to}`)).start();
  console.log()
  zipFolder(from, to);
  spinner.stop();
}
