const templateDir = path.resolve(__dirname, '../templates');

function init () {
  if (!fs.existsSync(templateDir)) {
    fs.mkdirSync(templateDir);
  }
}
