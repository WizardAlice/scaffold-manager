const templateDir = path.resolve(__dirname, '../templates');

export function init () {
  if (!fs.existsSync(templateDir)) {
    fs.mkdirSync(templateDir);
  }
}
