import fs from 'fs';
import path from 'path';

const templateDir = path.resolve(__dirname, '../templates/zip');

export function init () {

  if (!fs.existsSync(templateDir)) {
    fs.mkdirSync(templateDir);
  }

}
