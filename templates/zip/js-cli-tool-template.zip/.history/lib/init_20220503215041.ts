import fs from 'fs';
import path from 'path';

export const templateDir = path.resolve(__dirname, '../templates/zip');
export const templateZipDir = path.resolve(__dirname, '../templates/zip');
export const templatePackageDir = path.resolve(__dirname, '../templates/zip');

export function init () {

  if (!fs.existsSync(templateDir)) {
    fs.mkdirSync(templateDir);
  }

}
