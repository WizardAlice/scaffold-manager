// rollup.config.js

export default { // 可以是一个数组
  // 核心输入参数
  external, // 排除不需要被打包到文件内的模块
  input, // entry，可以有多个输入
  plugins, // 插件列表

  // 高级参数
  cache,
  onwarn,
  preserveEntrySignatures,
  strictDeprecations,

  // danger zone
  acorn,
  acornInjectPlugins,
  context,
  moduleContext,
  preserveSymlinks,
  shimMissingExports,
  treeshake,

  // experimental
  experimentalCacheExpiry,
  perf,

  output: { 可以是数组，同一个输入有多份输出
    // 核心输出参数
    dir,  // 多entry的时候需要这个参数
    file, // 单entry的时候需要定义这个参数,与dir参数不能同时使用
    format, // 输出文件的模块规范，amd、cmd、es module
    globals, // 针对输出umd/iife格式的时候，导入的全局变量
    name, // 针对输出iife/umd格式时的，包的全局变量名称或者自执行之后接收变量
    plugins, // 此插件仅处理该output内容，仅限于使用在 bundle.generate() 或 bundle.write() 期间运行的钩子的插件，即在 Rollup 的主要分析完成之后

    // advanced output options
    assetFileNames, // 自定义输出文件的名称[extname][]
    banner,
    chunkFileNames, // 异步加载chunk [hash][format][name]
    compact,
    entryFileNames, // 入口chunk [name][hash][format]
    extend,
    footer,
    hoistTransitiveImports, // 模块导入优化项
    inlineDynamicImports,
    interop, // 导入外部模块的方式
    intro,
    manualChunks, // 提取chunk
    minifyInternalExports,
    outro,
    paths, // 将模块id替换成路径，比如资源换成cnd路径
    preserveModules,  // 生成的模块按照原目录结构生成
    preserveModulesRoot, // 配合preserveModules使用
    sourcemap,
    sourcemapExcludeSources,
    sourcemapFile,
    sourcemapPathTransform,
    validate,

    // danger zone
    amd,
    esModule,
    exports, // 模块内部导出方式
    externalLiveBindings,
    freeze,
    indent,
    namespaceToStringTag,
    noConflict,
    preferConst,
    sanitizeFileName,
    strict,
    systemNullSetters
  },

  watch: {
    buildDelay,
    chokidar,
    clearScreen,
    skipWrite,
    exclude,
    include
  } | false
};
