export default {
  input: 'bin/*.ts',
  output: {
    file: 'bundle.js',
    format: 'cjs'
  }
};
