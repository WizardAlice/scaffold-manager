export default {
  input: 'bin/env.ts',
  output: {
    file: 'bundle.js',
    format: 'cjs'
  }
};
