export default {
  input: 'bin/*.ts',
  output: {
    dir: 'lib',
    file: 'bundle.js',
    format: 'cjs'
  }
};
