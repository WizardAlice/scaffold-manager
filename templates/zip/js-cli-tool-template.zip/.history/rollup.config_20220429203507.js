export default {
  input: 'bin/*.ts',
  output: {
    dir: 'dist',
    file: 'bundle.js',
    format: 'cjs'
  }
};
