export default {
  input: 'bin/index.ts',
  output: {
    dir: 'dist',
    file: 'bundle.js',
    format: 'cjs'
  }
};
