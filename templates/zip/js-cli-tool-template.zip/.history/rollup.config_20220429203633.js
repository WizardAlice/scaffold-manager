export default {
  input: [
    'bin/main.ts'
  ],
  output: {
    dir: 'dist',
    file: 'bundle.js',
    format: 'cjs'
  }
};
