export default {
  input: [
    'bin/main.ts'
  ],
  output: {
    dir: 'dist',
    format: ['cjs', 'es']
  }
};
