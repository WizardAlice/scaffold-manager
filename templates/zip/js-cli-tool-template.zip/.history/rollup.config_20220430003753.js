export default {
  input: [
    'bin/main.ts'
  ],
  output: [{
    dir: 'dist',
    format: ['cjs', 'es']
  }, {
    dir: 'dist',
    format: ['cjs', 'es']
  }]
};
