export default {
  input: [
    'bin/main.ts'
  ],
  output: [{
    dir: 'dist/cjs',
    format: 'cjs'
  }, {
    dir: 'dist/es',
    format: 'es'
  }, {
    dir: 'dist/es',
    format: 'xxx'
  }]
};
