import json from 'rollup-plugin-json';
import resolve from 'rollup-plugin-node-resolve';

export default {
  input: [
    'bin/main.ts'
  ],
  output: [{
    dir: 'dist/cjs',
    format: 'cjs'
  }, {
    dir: 'dist/umd',
    format: 'umd'
  }],
  plugins: [ json(), resolve() ]
};
