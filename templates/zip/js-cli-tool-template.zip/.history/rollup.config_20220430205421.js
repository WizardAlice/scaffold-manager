import json from 'rollup-plugin-json';
import commonjs from 'rollup-plugin-commonjs';
import nodeResolve from 'rollup-plugin-node-resolve';
import { babel } from '@rollup/plugin-babel';
import builtins from 'rollup-plugin-node-builtins';
import typescript from '@rollup/plugin-typescript';
import y18n from 'y18n';

export default {
  input: [
    'bin/main.ts'
  ],
  output: [{
    dir: 'dist/cjs',
    format: 'cjs'
  }, {
    dir: 'dist/es',
    format: 'es'
  }, {
    dir: 'dist/umd',
    format: 'umd'
  }],
  plugins: [
    json(),
    nodeResolve({
      mainFields: ['module'], // Default: ['module', 'main']
      extensions: [ '.mjs', '.js', '.jsx', '.json' ],  // Default: [ '.mjs', '.js', '.json', '.node' ]
      preferBuiltins: true,  // Default: true
      modulesOnly: false, // Default: false
      dedupe: [], // Default: []
      customResolveOptions: {
        moduleDirectory: 'node_modules'
      }
    }),
    builtins(),
    commonjs({
      // namedExports: {'fs': ['statSync', 'readdirSync']}
    }),
    typescript(),
  ]
};
