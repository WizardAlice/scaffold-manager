import commonjs from 'rollup-plugin-commonjs';
import builtins from 'rollup-plugin-node-builtins';
import babel from 'rollup-plugin-babel';
import dts from 'rollup-plugin-dts';
import typescript from '@rollup/plugin-typescript';

export default {
  input: [
    'bin/main.ts'
  ],
  output: [{
    dir: 'dist/cjs',
    format: 'cjs'
  }, {
    dir: 'dist/es',
    format: 'es'
  }, {
    dir: 'dist/umd',
    format: 'umd'
  }],
  plugins: [
    builtins(),
    commonjs({
      namedExports: {}
    }),
    babel({
      exclude: 'node_modules/**' // 只编译我们的源代码
    }),
    typescript(),
  ]
};
