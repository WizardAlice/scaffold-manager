import commonjs from 'rollup-plugin-commonjs';
import nodeResolve from 'rollup-plugin-node-resolve';
import builtins from 'rollup-plugin-node-builtins';
import babel from 'rollup-plugin-babel';
import dts from 'rollup-plugin-dts';
import typescript from '@rollup/plugin-typescript';

export default {
  input: [
    'bin/main.ts'
  ],
  output: [{
    dir: 'dist/cjs',
    format: 'cjs'
  }, {
    dir: 'dist/es',
    format: 'es'
  }, {
    dir: 'dist/umd',
    format: 'umd'
  }, {
    file: "dist/index.d.ts",
    format: "es"
  }],
  plugins: [
    nodeResolve({
      mainFields: ['module'], // Default: ['module', 'main']
      extensions: ['.mjs', '.js', '.jsx'],
      preferBuiltins: true, // Default: true
      modulesOnly: false, // Default: false
      dedupe: [], // Default: []
      customResolveOptions: {
        moduleDirectory: 'node_modules'
      }
    }),
    builtins(),
    commonjs({
      namedExports: {}
    }),
    babel({
      exclude: 'node_modules/**' // 只编译我们的源代码
    }),
    typescript(),
    dts(),
  ]
};
