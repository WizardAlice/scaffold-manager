import fs from "fs";
import path from "path";
import nodeResolve from 'rollup-plugin-node-resolve';
import builtins from 'rollup-plugin-node-builtins';
import babel from 'rollup-plugin-babel';
import dts from 'rollup-plugin-dts';
import typescript from '@rollup/plugin-typescript';
import {
  cleandir
} from "rollup-plugin-cleandir";

const dirname = Path.resolve(__dirname, 'bin');

const files = [];

function travel(dir) {
  fs.readdirSync(dir).forEach((file) => {
    var pathname = path.join(dir, file)
    if (fs.statSync(pathname).isDirectory()) {
      travel(pathname)
    } else {
      files.push(pathname);
    }
  })
}

travel(dirname);

const config = [{
    input: [
      ...files
    ],
    output: [{
      dir: 'dist/cjs',
      format: 'cjs'
    }, {
      dir: 'dist/es',
      format: 'es'
    }, {
      dir: 'dist/umd',
      format: 'umd'
    }],
    plugins: [
      cleandir("./dist"),
      nodeResolve({
        mainFields: ['module'], // Default: ['module', 'main']
        extensions: ['.mjs', '.js', '.jsx'],
        preferBuiltins: true, // Default: true
        modulesOnly: false, // Default: false
        dedupe: [], // Default: []
        customResolveOptions: {
          moduleDirectory: 'node_modules'
        }
      }),
      builtins(),
      babel({
        exclude: 'node_modules/**' // 只编译我们的源代码
      }),
      typescript(),
    ]
  },
  {
    input: [
      'bin/main.ts'
    ],
    output: [{
      file: "dist/index.d.ts",
      format: "es"
    }],
    plugins: [
      typescript(),
      dts(),
    ]
  }
];

export default config;
