import json from '@rollup/plugin-json';

function checkVersion() {

}
